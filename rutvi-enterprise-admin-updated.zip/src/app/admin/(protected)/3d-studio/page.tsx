import { db } from "@/lib/db";
import { websiteSettings } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import { save3DStudioSettings } from "@/app/admin/actions";
import { SubmitButton } from "@/components/admin/submit-button";

const fallback = {
  modelUrl: "", background: "#f5f2ea", boxColor: "#f4f0e8", ribbonColor: "#171717",
  rotationEnabled: true, rotationSpeed: 0.6, zoomEnabled: true, unwrapLabel: "Unwrap your gift", introEnabled: true,
};

function Field({ label, name, value, type = "text", hint }: { label: string; name: string; value: string | number; type?: string; hint?: string }) {
  return <label className="block"><span className="mb-1 block text-[0.62rem] uppercase tracking-[0.12em] text-stone">{label}</span><input className="field !min-h-10 text-xs" name={name} type={type} defaultValue={value} />{hint && <span className="mt-1 block text-[0.62rem] text-stone">{hint}</span>}</label>;
}

export default async function ThreeDStudioPage() {
  let config = fallback;
  try {
    const [row] = await db.select().from(websiteSettings).where(eq(websiteSettings.key, "3dStudio")).limit(1);
    if (row?.value) config = { ...fallback, ...row.value } as typeof fallback;
  } catch { /* defaults keep the page available if settings have not been migrated yet */ }
  return <div className="space-y-5">
    <header><p className="text-[0.62rem] font-semibold uppercase tracking-[0.2em] text-gold">Experience controls</p><h1 className="display mt-1 text-4xl text-ink">3D Experience Studio</h1><p className="mt-1 text-sm text-ink/50">Manage the saved presentation settings for the interactive gift box.</p></header>
    <form action={save3DStudioSettings} className="space-y-5">
      <section className="surface rounded-xl p-5"><h2 className="text-sm font-semibold text-ink">Model & appearance</h2><p className="mt-1 text-xs text-stone">Use a hosted GLB/GLTF model URL. These settings are saved in the website settings store.</p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2"><div className="sm:col-span-2"><Field label="3D model URL (GLB/GLTF)" name="modelUrl" value={config.modelUrl} hint="Use a publicly accessible asset URL or your configured upload URL." /></div><Field label="Scene background" name="background" value={config.background} type="color"/><Field label="Gift box colour" name="boxColor" value={config.boxColor} type="color"/><Field label="Ribbon colour" name="ribbonColor" value={config.ribbonColor} type="color"/><Field label="Rotation speed" name="rotationSpeed" value={config.rotationSpeed} type="number"/></div>
      </section>
      <section className="surface rounded-xl p-5"><h2 className="text-sm font-semibold text-ink">Interaction & reveal</h2><div className="mt-4 space-y-3"><label className="flex items-center gap-2 text-xs text-ink"><input type="checkbox" name="rotationEnabled" defaultChecked={config.rotationEnabled}/> Enable user rotation</label><label className="flex items-center gap-2 text-xs text-ink"><input type="checkbox" name="zoomEnabled" defaultChecked={config.zoomEnabled}/> Enable zoom controls</label><label className="flex items-center gap-2 text-xs text-ink"><input type="checkbox" name="introEnabled" defaultChecked={config.introEnabled}/> Enable intro animation</label><Field label="Unwrap button label" name="unwrapLabel" value={config.unwrapLabel}/></div></section>
      <div className="sticky bottom-4 flex justify-end"><SubmitButton className="btn-base btn-navy shadow-lg" pendingLabel="Saving…">Save 3D settings</SubmitButton></div>
    </form>
    <p className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">Note: this page stores configuration. The live 3D viewer must read the saved <code>3dStudio</code> setting to apply these values to the rendered model.</p>
  </div>;
}
