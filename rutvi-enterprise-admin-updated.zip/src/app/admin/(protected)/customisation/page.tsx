import Link from "next/link";
import { ArrowUpRight, LayoutTemplate, Palette, Type, Settings, Sparkles } from "lucide-react";

const tools = [
  { title: "Homepage content", description: "Edit the hero headline, description, CTA labels, footer copy and contact details using the existing settings form.", href: "/admin/settings", icon: Type, status: "Connected" },
  { title: "Brand & appearance", description: "Review the current brand assets and settings. Global theme editing is not yet connected to a persisted setting.", href: "/admin/settings", icon: Palette, status: "Settings available" },
  { title: "Homepage sections", description: "Inspect the homepage sections and plan content updates. Drag-and-drop section ordering requires a section CMS backend.", href: "/admin/settings", icon: LayoutTemplate, status: "Coming next" },
  { title: "Website settings", description: "Manage business contact information, location, social links, hero copy and testimonials.", href: "/admin/settings", icon: Settings, status: "Connected" },
];

export default function AdminCustomisationPage() {
  return <div className="space-y-6">
    <div><p className="text-[0.62rem] font-semibold uppercase tracking-[0.2em] text-gold">Website control centre</p><h1 className="display mt-1 text-4xl text-ink">Customisation</h1><p className="mt-1 max-w-2xl text-sm text-ink/50">Manage the website's existing editable content from one place. Connected tools open the current production settings workflow.</p></div>
    <div className="grid gap-3 sm:grid-cols-2">
      {tools.map((tool) => <Link key={tool.title} href={tool.href} className="surface group rounded-xl p-5 transition-shadow hover:shadow-lg"><div className="flex items-start justify-between"><span className="grid size-10 place-items-center rounded-lg bg-cream text-navy"><tool.icon className="size-4"/></span><ArrowUpRight className="size-4 text-ink/25 group-hover:text-navy"/></div><div className="mt-4 flex items-center justify-between gap-2"><h2 className="text-sm font-semibold text-ink">{tool.title}</h2><span className="rounded-full border border-ink/10 px-2 py-1 text-[0.55rem] text-stone">{tool.status}</span></div><p className="mt-2 text-xs leading-5 text-ink/55">{tool.description}</p></Link>)}
    </div>
    <section className="rounded-xl bg-navy p-5 text-ivory"><div className="flex items-center gap-2 text-gold"><Sparkles className="size-4"/><p className="text-[0.6rem] font-semibold uppercase tracking-[0.18em]">Publishing note</p></div><p className="mt-2 text-sm text-ivory/75">Website settings currently save directly to the live site. Preview, staged publishing and rollback are not implemented in this project yet, so review changes carefully before saving.</p></section>
  </div>;
}
