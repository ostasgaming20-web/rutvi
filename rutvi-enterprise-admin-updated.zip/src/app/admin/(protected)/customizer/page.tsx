import { eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { websiteSettings } from "@/lib/db/schema";
import { saveVisualEditorSettings } from "@/app/admin/actions";
import { SubmitButton } from "@/components/admin/submit-button";

const fallback = { announcement: "", announcementEnabled: false, heroBackground: "#f5f2ea", accentColor: "#b99a62", heroTitle: "", heroSubtitle: "", primaryButtonLabel: "Explore our collection", primaryButtonHref: "/products" };
function Field({ label, name, value, type = "text" }: { label: string; name: string; value: string; type?: string }) { return <label className="block"><span className="mb-1 block text-[0.62rem] uppercase tracking-[0.12em] text-stone">{label}</span><input name={name} type={type} defaultValue={value} className="field !min-h-10 text-xs" /></label>; }
export default async function CustomizerPage() {
  let config = fallback;
  try { const [row] = await db.select().from(websiteSettings).where(eq(websiteSettings.key, "visualEditor")).limit(1); if (row?.value) config = { ...fallback, ...row.value } as typeof fallback; } catch { /* use defaults */ }
  return <div className="space-y-5"><header><p className="text-[0.62rem] font-semibold uppercase tracking-[0.2em] text-gold">Content & brand</p><h1 className="display mt-1 text-4xl text-ink">Website editor</h1><p className="mt-1 text-sm text-ink/50">Configure key homepage presentation fields.</p></header>
    <form action={saveVisualEditorSettings} className="space-y-5"><section className="surface rounded-xl p-5"><h2 className="text-sm font-semibold text-ink">Announcement bar</h2><div className="mt-3 space-y-3"><Field label="Announcement text" name="announcement" value={config.announcement}/><label className="flex items-center gap-2 text-xs"><input type="checkbox" name="announcementEnabled" defaultChecked={config.announcementEnabled}/> Show announcement bar</label></div></section>
    <section className="surface rounded-xl p-5"><h2 className="text-sm font-semibold text-ink">Hero appearance</h2><div className="mt-3 grid gap-4 sm:grid-cols-2"><Field label="Hero background" name="heroBackground" value={config.heroBackground} type="color"/><Field label="Brand accent" name="accentColor" value={config.accentColor} type="color"/><div className="sm:col-span-2"><Field label="Hero title" name="heroTitle" value={config.heroTitle}/></div><div className="sm:col-span-2"><Field label="Hero subtitle" name="heroSubtitle" value={config.heroSubtitle}/></div><Field label="Primary button label" name="primaryButtonLabel" value={config.primaryButtonLabel}/><Field label="Primary button destination" name="primaryButtonHref" value={config.primaryButtonHref}/></div></section><div className="sticky bottom-4 flex justify-end"><SubmitButton className="btn-base btn-navy shadow-lg" pendingLabel="Saving…">Save editor settings</SubmitButton></div></form>
    <p className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">Note: these values are persisted in the website settings store. Connect the corresponding homepage components to the <code>visualEditor</code> setting before expecting them to alter the public-facing page.</p>
  </div>;
}
