import { readdir } from "node:fs/promises";
import path from "node:path";
import Link from "next/link";
import { Image as ImageIcon, FolderOpen } from "lucide-react";

export default async function MediaLibraryPage() {
  const root = path.join(process.cwd(), "public", "uploads");
  let files: string[] = [];
  try { files = (await readdir(path.join(root, "products"))).filter((f) => !f.startsWith(".")); } catch { files = []; }
  return <div className="space-y-6">
    <div><p className="text-[0.62rem] font-semibold uppercase tracking-[0.2em] text-gold">Assets</p><h1 className="display mt-1 text-4xl text-ink">Media library</h1><p className="mt-1 text-sm text-ink/50">Product media currently stored in the project's public uploads folder.</p></div>
    <section className="surface rounded-xl p-5"><div className="flex items-center gap-2"><FolderOpen className="size-4 text-gold"/><h2 className="text-sm font-semibold">Product uploads</h2><span className="ml-auto text-xs text-stone">{files.length} files</span></div>
      {files.length ? <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{files.map((file) => <a key={file} href={`/uploads/products/${encodeURIComponent(file)}`} target="_blank" rel="noreferrer" className="rounded-lg border border-ink/8 p-3 hover:bg-cream/40"><div className="mb-2 flex h-28 items-center justify-center overflow-hidden rounded bg-cream"><img src={`/uploads/products/${encodeURIComponent(file)}`} alt={file} className="max-h-full max-w-full object-contain"/></div><p className="break-all text-[0.65rem] text-ink/70">{file}</p></a>)}</div> : <p className="mt-4 text-xs text-stone">No product uploads found.</p>}
    </section><p className="text-xs text-stone">This view lists existing assets. Upload, delete and metadata editing are not connected to a media database yet.</p><Link href="/admin/products" className="text-xs font-semibold text-navy underline">Manage product records</Link>
  </div>;
}
